--
-- PostgreSQL database dump
--

\restrict 4LKccdtQgsu6X0lZc4h5dtPNwPid50xrZ9cidFtqfSwsQDgtgPKbi1bE8h4b80F

-- Dumped from database version 17.10 (Debian 17.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: opencode_pocket; Type: SCHEMA; Schema: -; Owner: llm_gateway
--

CREATE SCHEMA opencode_pocket;


ALTER SCHEMA opencode_pocket OWNER TO llm_gateway;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.agents (
    id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    instance_id text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'generic'::text NOT NULL,
    status text DEFAULT 'unknown'::text NOT NULL,
    capabilities jsonb DEFAULT '[]'::jsonb,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.agents OWNER TO llm_gateway;

--
-- Name: approval_observations; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.approval_observations (
    workspace_id text NOT NULL,
    instance_id text NOT NULL,
    session_id text NOT NULL,
    request_id text NOT NULL,
    kind text NOT NULL,
    state text NOT NULL,
    version bigint NOT NULL,
    decision text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.approval_observations OWNER TO llm_gateway;

--
-- Name: asset_mirrors; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.asset_mirrors (
    id text NOT NULL,
    workspace_id text NOT NULL,
    kind text DEFAULT 'note'::text NOT NULL,
    client_rev integer DEFAULT 1 NOT NULL,
    server_rev integer DEFAULT 1 NOT NULL,
    cipher_title text DEFAULT ''::text,
    cipher_blob text DEFAULT ''::text NOT NULL,
    deleted_at bigint DEFAULT 0 NOT NULL,
    updated_at bigint DEFAULT 0 NOT NULL
);


ALTER TABLE opencode_pocket.asset_mirrors OWNER TO llm_gateway;

--
-- Name: asset_sync_log; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.asset_sync_log (
    id bigint NOT NULL,
    workspace_id text NOT NULL,
    asset_id text NOT NULL,
    op text NOT NULL,
    client_rev integer,
    server_rev integer,
    detail text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE opencode_pocket.asset_sync_log OWNER TO llm_gateway;

--
-- Name: asset_sync_log_id_seq; Type: SEQUENCE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE SEQUENCE opencode_pocket.asset_sync_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE opencode_pocket.asset_sync_log_id_seq OWNER TO llm_gateway;

--
-- Name: asset_sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER SEQUENCE opencode_pocket.asset_sync_log_id_seq OWNED BY opencode_pocket.asset_sync_log.id;


--
-- Name: asset_workspace_revisions; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.asset_workspace_revisions (
    workspace_id text NOT NULL,
    last_revision bigint DEFAULT 0 NOT NULL
);


ALTER TABLE opencode_pocket.asset_workspace_revisions OWNER TO llm_gateway;

--
-- Name: audit_entries; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.audit_entries (
    id text NOT NULL,
    action text NOT NULL,
    user_id text NOT NULL,
    tenant_id text NOT NULL,
    resource text,
    detail text,
    duration_ms bigint,
    success boolean NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    ip text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE opencode_pocket.audit_entries OWNER TO llm_gateway;

--
-- Name: biometric_credentials; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.biometric_credentials (
    id text NOT NULL,
    user_id text NOT NULL,
    workspace_id text NOT NULL,
    device_name text DEFAULT ''::text NOT NULL,
    public_key bytea NOT NULL,
    counter bigint DEFAULT 0 NOT NULL,
    transports text DEFAULT '[]'::text NOT NULL,
    created_at bigint NOT NULL,
    last_used_at bigint DEFAULT 0 NOT NULL
);


ALTER TABLE opencode_pocket.biometric_credentials OWNER TO llm_gateway;

--
-- Name: chat_agent_sync; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.chat_agent_sync (
    workspace_id text NOT NULL,
    user_id text NOT NULL,
    version bigint NOT NULL,
    agents_json text DEFAULT '[]'::text NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.chat_agent_sync OWNER TO llm_gateway;

--
-- Name: chat_agents; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.chat_agents (
    id text NOT NULL,
    workspace_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    department text NOT NULL,
    emoji text,
    color text,
    system_prompt text NOT NULL,
    is_builtin integer DEFAULT 0 NOT NULL,
    created_at integer NOT NULL,
    updated_at integer NOT NULL
);


ALTER TABLE opencode_pocket.chat_agents OWNER TO llm_gateway;

--
-- Name: daily_summaries; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.daily_summaries (
    id text NOT NULL,
    user_id text NOT NULL,
    summary_date date NOT NULL,
    total_count integer,
    important_count integer,
    content text NOT NULL,
    action_items text,
    created_at bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL
);


ALTER TABLE opencode_pocket.daily_summaries OWNER TO llm_gateway;

--
-- Name: devices; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.devices (
    id text NOT NULL,
    user_id text NOT NULL,
    workspace_id text NOT NULL,
    fingerprint text NOT NULL,
    push_token text,
    os text,
    last_seen_at bigint NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.devices OWNER TO llm_gateway;

--
-- Name: email_accounts; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.email_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    display_name text NOT NULL,
    email_address text NOT NULL,
    imap_host text NOT NULL,
    imap_port integer DEFAULT 993,
    auth_type text DEFAULT 'password'::text,
    credential_encrypted text NOT NULL,
    sync_interval_min integer DEFAULT 15,
    last_synced_uid bigint,
    last_synced_at bigint,
    rules text,
    enabled boolean DEFAULT true,
    created_at bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    smtp_host text DEFAULT ''::text NOT NULL,
    smtp_port integer DEFAULT 0 NOT NULL,
    smtp_credential_encrypted text DEFAULT ''::text NOT NULL,
    CONSTRAINT email_accounts_auth_type_check CHECK ((auth_type = ANY (ARRAY['password'::text, 'oauth2'::text])))
);


ALTER TABLE opencode_pocket.email_accounts OWNER TO llm_gateway;

--
-- Name: email_action_intents; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.email_action_intents (
    id text NOT NULL,
    email_id text NOT NULL,
    account_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    folder text DEFAULT ''::text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    idempotency_key text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    applied_at bigint,
    CONSTRAINT email_action_intents_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'applied'::text, 'failed'::text, 'skipped'::text])))
);


ALTER TABLE opencode_pocket.email_action_intents OWNER TO llm_gateway;

--
-- Name: email_oauth_tokens; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.email_oauth_tokens (
    account_id text NOT NULL,
    refresh_token_encrypted text NOT NULL,
    access_token_encrypted text,
    expires_at bigint DEFAULT 0 NOT NULL,
    scope text,
    updated_at bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text DEFAULT ''::text NOT NULL
);


ALTER TABLE opencode_pocket.email_oauth_tokens OWNER TO llm_gateway;

--
-- Name: email_vacation_deliveries; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.email_vacation_deliveries (
    vacation_id text NOT NULL,
    email_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    recipient text NOT NULL,
    original_message_id text DEFAULT ''::text NOT NULL,
    status text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    claimed_at bigint NOT NULL,
    sent_at bigint,
    updated_at bigint NOT NULL,
    CONSTRAINT email_vacation_deliveries_status_check CHECK ((status = ANY (ARRAY['claimed'::text, 'sent'::text, 'failed'::text])))
);


ALTER TABLE opencode_pocket.email_vacation_deliveries OWNER TO llm_gateway;

--
-- Name: email_vacation_replies; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.email_vacation_replies (
    id text NOT NULL,
    account_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    start_at bigint NOT NULL,
    end_at bigint NOT NULL,
    subject text NOT NULL,
    body_text text NOT NULL,
    last_sent_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.email_vacation_replies OWNER TO llm_gateway;

--
-- Name: emails; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.emails (
    id text NOT NULL,
    account_id text NOT NULL,
    message_id text,
    uid bigint,
    from_address text NOT NULL,
    from_name text,
    to_addresses text,
    subject text,
    snippet text,
    body_path text,
    has_attachments boolean DEFAULT false,
    attachments text,
    date bigint NOT NULL,
    is_read boolean DEFAULT false,
    is_starred boolean DEFAULT false,
    category text,
    importance text,
    ai_summary text,
    suggested_action text,
    action_reason text,
    processed_at bigint,
    created_at bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL
);


ALTER TABLE opencode_pocket.emails OWNER TO llm_gateway;

--
-- Name: llm_gateway_configs; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.llm_gateway_configs (
    id integer NOT NULL,
    base_url text NOT NULL,
    api_key_encrypted text DEFAULT ''::text NOT NULL,
    models jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    workspace_id text DEFAULT 'default'::text NOT NULL,
    format text DEFAULT 'openai-chat'::text NOT NULL,
    preferred_models jsonb DEFAULT '[]'::jsonb
);


ALTER TABLE opencode_pocket.llm_gateway_configs OWNER TO llm_gateway;

--
-- Name: llm_gateway_configs_id_seq; Type: SEQUENCE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE SEQUENCE opencode_pocket.llm_gateway_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE opencode_pocket.llm_gateway_configs_id_seq OWNER TO llm_gateway;

--
-- Name: llm_gateway_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER SEQUENCE opencode_pocket.llm_gateway_configs_id_seq OWNED BY opencode_pocket.llm_gateway_configs.id;


--
-- Name: llm_gateway_nodes; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.llm_gateway_nodes (
    id bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    name text NOT NULL,
    base_url text NOT NULL,
    admin_username text DEFAULT ''::text NOT NULL,
    admin_password_encrypted text DEFAULT ''::text NOT NULL,
    data_api_key_encrypted text DEFAULT ''::text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    last_health_status text DEFAULT 'unknown'::text NOT NULL,
    last_health_error text DEFAULT ''::text NOT NULL,
    last_health_role text DEFAULT ''::text NOT NULL,
    last_health_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE opencode_pocket.llm_gateway_nodes OWNER TO llm_gateway;

--
-- Name: llm_gateway_nodes_id_seq; Type: SEQUENCE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE SEQUENCE opencode_pocket.llm_gateway_nodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE opencode_pocket.llm_gateway_nodes_id_seq OWNER TO llm_gateway;

--
-- Name: llm_gateway_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER SEQUENCE opencode_pocket.llm_gateway_nodes_id_seq OWNED BY opencode_pocket.llm_gateway_nodes.id;


--
-- Name: model_usage; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.model_usage (
    id bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text DEFAULT ''::text NOT NULL,
    model text NOT NULL,
    kind text DEFAULT 'chat'::text NOT NULL,
    prompt_tokens integer DEFAULT 0 NOT NULL,
    completion_tokens integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    cost_usd double precision DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE opencode_pocket.model_usage OWNER TO llm_gateway;

--
-- Name: model_usage_id_seq; Type: SEQUENCE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE SEQUENCE opencode_pocket.model_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE opencode_pocket.model_usage_id_seq OWNER TO llm_gateway;

--
-- Name: model_usage_id_seq; Type: SEQUENCE OWNED BY; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER SEQUENCE opencode_pocket.model_usage_id_seq OWNED BY opencode_pocket.model_usage.id;


--
-- Name: notes; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.notes (
    id text NOT NULL,
    user_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text,
    title text,
    content text DEFAULT ''::text NOT NULL,
    snippet text,
    content_type text DEFAULT 'voice'::text,
    domain text,
    tags jsonb DEFAULT '[]'::jsonb,
    audio_path text,
    audio_duration integer DEFAULT 0,
    created_by_voice boolean DEFAULT true,
    ai_summary text,
    confidence_score real,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone
);


ALTER TABLE opencode_pocket.notes OWNER TO llm_gateway;

--
-- Name: notification_rules; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.notification_rules (
    id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    kind text DEFAULT ''::text NOT NULL,
    channels jsonb DEFAULT '["inbox"]'::jsonb,
    priority text DEFAULT 'normal'::text NOT NULL,
    quiet_start_min integer DEFAULT 0 NOT NULL,
    quiet_end_min integer DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE opencode_pocket.notification_rules OWNER TO llm_gateway;

--
-- Name: notifications; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.notifications (
    id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'system'::text NOT NULL,
    kind text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    payload jsonb,
    priority text DEFAULT 'normal'::text NOT NULL,
    read_at bigint DEFAULT 0 NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.notifications OWNER TO llm_gateway;

--
-- Name: quota_budgets; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.quota_budgets (
    id bigint NOT NULL,
    workspace_id text NOT NULL,
    kind text NOT NULL,
    limit_value double precision NOT NULL,
    period_start timestamp with time zone,
    period_end timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE opencode_pocket.quota_budgets OWNER TO llm_gateway;

--
-- Name: quota_budgets_id_seq; Type: SEQUENCE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE SEQUENCE opencode_pocket.quota_budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE opencode_pocket.quota_budgets_id_seq OWNER TO llm_gateway;

--
-- Name: quota_budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER SEQUENCE opencode_pocket.quota_budgets_id_seq OWNED BY opencode_pocket.quota_budgets.id;


--
-- Name: scheduled_task_runs; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.scheduled_task_runs (
    id text NOT NULL,
    task_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    started_at bigint NOT NULL,
    finished_at bigint DEFAULT 0 NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    output jsonb DEFAULT '{}'::jsonb NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    referenced_task_id text DEFAULT ''::text NOT NULL
);


ALTER TABLE opencode_pocket.scheduled_task_runs OWNER TO llm_gateway;

--
-- Name: scheduled_tasks; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.scheduled_tasks (
    id text NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    kind text NOT NULL,
    schedule_kind text NOT NULL,
    schedule_expr text NOT NULL,
    timezone text DEFAULT 'Asia/Shanghai'::text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    next_run_at bigint DEFAULT 0 NOT NULL,
    lease_until bigint DEFAULT 0 NOT NULL,
    last_run_at bigint DEFAULT 0 NOT NULL,
    last_status text DEFAULT ''::text NOT NULL,
    last_error text DEFAULT ''::text NOT NULL,
    run_count integer DEFAULT 0 NOT NULL,
    max_runs integer DEFAULT 0 NOT NULL,
    cooldown_sec integer DEFAULT 0 NOT NULL,
    timeout_sec integer DEFAULT 120 NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.scheduled_tasks OWNER TO llm_gateway;

--
-- Name: task_approval_projections; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.task_approval_projections (
    workspace_id text NOT NULL,
    task_id text NOT NULL,
    instance_id text NOT NULL,
    session_id text NOT NULL,
    request_id text NOT NULL,
    kind text NOT NULL,
    state text NOT NULL,
    version bigint NOT NULL,
    decision text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.task_approval_projections OWNER TO llm_gateway;

--
-- Name: task_session_links; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.task_session_links (
    task_id text NOT NULL,
    instance_id text NOT NULL,
    session_id text NOT NULL,
    role text NOT NULL,
    attached_at bigint NOT NULL,
    workspace_id text DEFAULT 'default'::text NOT NULL
);


ALTER TABLE opencode_pocket.task_session_links OWNER TO llm_gateway;

--
-- Name: tasks; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.tasks (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    status text NOT NULL,
    priority text NOT NULL,
    workstream_id text,
    source text DEFAULT 'local'::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    pending_approvals integer DEFAULT 0,
    session_count integer DEFAULT 0,
    workspace_id text DEFAULT 'default'::text NOT NULL,
    accepted_at bigint,
    accepted_by text,
    acceptance_criteria jsonb,
    evidence_bundle jsonb
);


ALTER TABLE opencode_pocket.tasks OWNER TO llm_gateway;

--
-- Name: users; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.users (
    id text NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.users OWNER TO llm_gateway;

--
-- Name: vault_sync; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.vault_sync (
    workspace_id text DEFAULT 'default'::text NOT NULL,
    user_id text NOT NULL,
    blob_ciphertext text NOT NULL,
    version integer NOT NULL,
    is_current boolean DEFAULT true,
    updated_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.vault_sync OWNER TO llm_gateway;

--
-- Name: workspace_members; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.workspace_members (
    workspace_id text NOT NULL,
    user_id text NOT NULL,
    role text NOT NULL,
    invited_at bigint NOT NULL,
    expires_at bigint DEFAULT 0 NOT NULL
);


ALTER TABLE opencode_pocket.workspace_members OWNER TO llm_gateway;

--
-- Name: workspaces; Type: TABLE; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE TABLE opencode_pocket.workspaces (
    id text NOT NULL,
    owner_id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'default'::text NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE opencode_pocket.workspaces OWNER TO llm_gateway;

--
-- Name: daily_summaries; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.daily_summaries (
    id text NOT NULL,
    user_id text NOT NULL,
    summary_date date NOT NULL,
    total_count integer,
    important_count integer,
    content text NOT NULL,
    action_items text,
    created_at bigint NOT NULL
);


ALTER TABLE public.daily_summaries OWNER TO llm_gateway;

--
-- Name: email_accounts; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.email_accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    display_name text NOT NULL,
    email_address text NOT NULL,
    imap_host text NOT NULL,
    imap_port integer DEFAULT 993,
    auth_type text DEFAULT 'password'::text,
    credential_encrypted text NOT NULL,
    sync_interval_min integer DEFAULT 15,
    last_synced_uid bigint,
    last_synced_at bigint,
    rules text,
    enabled boolean DEFAULT true,
    created_at bigint NOT NULL,
    CONSTRAINT email_accounts_auth_type_check CHECK ((auth_type = ANY (ARRAY['password'::text, 'oauth2'::text])))
);


ALTER TABLE public.email_accounts OWNER TO llm_gateway;

--
-- Name: emails; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.emails (
    id text NOT NULL,
    account_id text NOT NULL,
    message_id text,
    uid bigint,
    from_address text NOT NULL,
    from_name text,
    to_addresses text,
    subject text,
    snippet text,
    body_path text,
    has_attachments boolean DEFAULT false,
    attachments text,
    date bigint NOT NULL,
    is_read boolean DEFAULT false,
    is_starred boolean DEFAULT false,
    category text,
    importance text,
    ai_summary text,
    suggested_action text,
    action_reason text,
    processed_at bigint,
    created_at bigint NOT NULL
);


ALTER TABLE public.emails OWNER TO llm_gateway;

--
-- Name: notes; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.notes (
    id text NOT NULL,
    user_id text NOT NULL,
    workspace_id text DEFAULT 'default'::text,
    title text,
    content text DEFAULT ''::text NOT NULL,
    snippet text,
    content_type text DEFAULT 'voice'::text,
    domain text,
    tags jsonb DEFAULT '[]'::jsonb,
    audio_path text,
    audio_duration integer DEFAULT 0,
    created_by_voice boolean DEFAULT true,
    ai_summary text,
    confidence_score real,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone
);


ALTER TABLE public.notes OWNER TO llm_gateway;

--
-- Name: task_session_links; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.task_session_links (
    task_id text NOT NULL,
    instance_id text NOT NULL,
    session_id text NOT NULL,
    role text NOT NULL,
    attached_at bigint NOT NULL
);


ALTER TABLE public.task_session_links OWNER TO llm_gateway;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.tasks (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    status text NOT NULL,
    priority text NOT NULL,
    workstream_id text,
    source text DEFAULT 'local'::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    pending_approvals integer DEFAULT 0,
    session_count integer DEFAULT 0
);


ALTER TABLE public.tasks OWNER TO llm_gateway;

--
-- Name: users; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.users OWNER TO llm_gateway;

--
-- Name: vault_sync; Type: TABLE; Schema: public; Owner: llm_gateway
--

CREATE TABLE public.vault_sync (
    user_id text NOT NULL,
    blob_ciphertext text NOT NULL,
    version integer NOT NULL,
    is_current boolean DEFAULT true,
    updated_at bigint NOT NULL
);


ALTER TABLE public.vault_sync OWNER TO llm_gateway;

--
-- Name: asset_sync_log id; Type: DEFAULT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.asset_sync_log ALTER COLUMN id SET DEFAULT nextval('opencode_pocket.asset_sync_log_id_seq'::regclass);


--
-- Name: llm_gateway_configs id; Type: DEFAULT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.llm_gateway_configs ALTER COLUMN id SET DEFAULT nextval('opencode_pocket.llm_gateway_configs_id_seq'::regclass);


--
-- Name: llm_gateway_nodes id; Type: DEFAULT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.llm_gateway_nodes ALTER COLUMN id SET DEFAULT nextval('opencode_pocket.llm_gateway_nodes_id_seq'::regclass);


--
-- Name: model_usage id; Type: DEFAULT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.model_usage ALTER COLUMN id SET DEFAULT nextval('opencode_pocket.model_usage_id_seq'::regclass);


--
-- Name: quota_budgets id; Type: DEFAULT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.quota_budgets ALTER COLUMN id SET DEFAULT nextval('opencode_pocket.quota_budgets_id_seq'::regclass);


--
-- Data for Name: agents; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.agents (id, workspace_id, instance_id, name, role, status, capabilities, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: approval_observations; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.approval_observations (workspace_id, instance_id, session_id, request_id, kind, state, version, decision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_mirrors; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.asset_mirrors (id, workspace_id, kind, client_rev, server_rev, cipher_title, cipher_blob, deleted_at, updated_at) FROM stdin;
\.


--
-- Data for Name: asset_sync_log; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.asset_sync_log (id, workspace_id, asset_id, op, client_rev, server_rev, detail, created_at) FROM stdin;
\.


--
-- Data for Name: asset_workspace_revisions; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.asset_workspace_revisions (workspace_id, last_revision) FROM stdin;
\.


--
-- Data for Name: audit_entries; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.audit_entries (id, action, user_id, tenant_id, resource, detail, duration_ms, success, "timestamp", ip, created_at) FROM stdin;
aud_dfc8203496425e1af11fbed67026f955	llm_gateway.config.updated	user-admin	ws_user-admin	llm_gateway_config	base_url=https://llm.kxpms.cn api_key_set=true models_set=true	0	t	2026-08-31 06:10:02.085744+08		2026-08-31 06:10:02.085345+08
\.


--
-- Data for Name: biometric_credentials; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.biometric_credentials (id, user_id, workspace_id, device_name, public_key, counter, transports, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: chat_agent_sync; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.chat_agent_sync (workspace_id, user_id, version, agents_json, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_agents; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.chat_agents (id, workspace_id, name, description, department, emoji, color, system_prompt, is_builtin, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_summaries; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.daily_summaries (id, user_id, summary_date, total_count, important_count, content, action_items, created_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.devices (id, user_id, workspace_id, fingerprint, push_token, os, last_seen_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_accounts; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.email_accounts (id, user_id, display_name, email_address, imap_host, imap_port, auth_type, credential_encrypted, sync_interval_min, last_synced_uid, last_synced_at, rules, enabled, created_at, workspace_id, smtp_host, smtp_port, smtp_credential_encrypted) FROM stdin;
\.


--
-- Data for Name: email_action_intents; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.email_action_intents (id, email_id, account_id, workspace_id, user_id, action, folder, reason, idempotency_key, status, error, created_at, updated_at, applied_at) FROM stdin;
\.


--
-- Data for Name: email_oauth_tokens; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.email_oauth_tokens (account_id, refresh_token_encrypted, access_token_encrypted, expires_at, scope, updated_at, workspace_id, user_id) FROM stdin;
\.


--
-- Data for Name: email_vacation_deliveries; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.email_vacation_deliveries (vacation_id, email_id, workspace_id, recipient, original_message_id, status, error, claimed_at, sent_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_vacation_replies; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.email_vacation_replies (id, account_id, workspace_id, enabled, start_at, end_at, subject, body_text, last_sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: emails; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.emails (id, account_id, message_id, uid, from_address, from_name, to_addresses, subject, snippet, body_path, has_attachments, attachments, date, is_read, is_starred, category, importance, ai_summary, suggested_action, action_reason, processed_at, created_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: llm_gateway_configs; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.llm_gateway_configs (id, base_url, api_key_encrypted, models, is_active, created_at, workspace_id, format, preferred_models) FROM stdin;
1	https://llm.kxpms.cn/v1	xkJmks0p0rYrJfe6V0Towaz4ZVev0oCQOG6fBmYQXgCluCk+QWubob7WYL37LY0+UaBRTw1sgScwoakNZWYCui2dOgSm4RLbO8nCm+qrkw==	[]	t	2026-08-31 06:10:01.862873+08	ws_user-admin	openai-chat	[]
\.


--
-- Data for Name: llm_gateway_nodes; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.llm_gateway_nodes (id, workspace_id, name, base_url, admin_username, admin_password_encrypted, data_api_key_encrypted, enabled, last_health_status, last_health_error, last_health_role, last_health_at, created_at, updated_at) FROM stdin;
1	ws_user-admin	default	https://llm.kxpms.cn			xkJmks0p0rYrJfe6V0Towaz4ZVev0oCQOG6fBmYQXgCluCk+QWubob7WYL37LY0+UaBRTw1sgScwoakNZWYCui2dOgSm4RLbO8nCm+qrkw==	t	unknown			\N	2026-08-31 13:43:04.341892+08	2026-08-31 13:43:04.341892+08
\.


--
-- Data for Name: model_usage; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.model_usage (id, workspace_id, user_id, model, kind, prompt_tokens, completion_tokens, total_tokens, cost_usd, created_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.notes (id, user_id, workspace_id, title, content, snippet, content_type, domain, tags, audio_path, audio_duration, created_by_voice, ai_summary, confidence_score, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: notification_rules; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.notification_rules (id, workspace_id, source, kind, channels, priority, quiet_start_min, quiet_end_min, enabled) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.notifications (id, workspace_id, user_id, source, kind, title, body, payload, priority, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: quota_budgets; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.quota_budgets (id, workspace_id, kind, limit_value, period_start, period_end, created_at) FROM stdin;
\.


--
-- Data for Name: scheduled_task_runs; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.scheduled_task_runs (id, task_id, workspace_id, user_id, status, started_at, finished_at, duration_ms, output, error, referenced_task_id) FROM stdin;
\.


--
-- Data for Name: scheduled_tasks; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.scheduled_tasks (id, workspace_id, user_id, name, description, kind, schedule_kind, schedule_expr, timezone, payload, enabled, next_run_at, lease_until, last_run_at, last_status, last_error, run_count, max_runs, cooldown_sec, timeout_sec, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_approval_projections; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.task_approval_projections (workspace_id, task_id, instance_id, session_id, request_id, kind, state, version, decision, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_session_links; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.task_session_links (task_id, instance_id, session_id, role, attached_at, workspace_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.tasks (id, title, description, status, priority, workstream_id, source, created_at, updated_at, pending_approvals, session_count, workspace_id, accepted_at, accepted_by, acceptance_criteria, evidence_bundle) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.users (id, username, password_hash, role, created_at) FROM stdin;
user-admin	admin	$2a$10$6/MZtRAwbbXYQIBc4vI.nuaxAEpM0Ae5EfPx7gIIMCxIJcnTKLZsS	admin	1788125639
\.


--
-- Data for Name: vault_sync; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.vault_sync (workspace_id, user_id, blob_ciphertext, version, is_current, updated_at) FROM stdin;
\.


--
-- Data for Name: workspace_members; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.workspace_members (workspace_id, user_id, role, invited_at, expires_at) FROM stdin;
ws_user-admin	user-admin	owner	1788125653	0
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: opencode_pocket; Owner: llm_gateway
--

COPY opencode_pocket.workspaces (id, owner_id, name, type, created_at) FROM stdin;
ws_user-admin	user-admin	我的随身公司	default	1788125653
\.


--
-- Data for Name: daily_summaries; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.daily_summaries (id, user_id, summary_date, total_count, important_count, content, action_items, created_at) FROM stdin;
\.


--
-- Data for Name: email_accounts; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.email_accounts (id, user_id, display_name, email_address, imap_host, imap_port, auth_type, credential_encrypted, sync_interval_min, last_synced_uid, last_synced_at, rules, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: emails; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.emails (id, account_id, message_id, uid, from_address, from_name, to_addresses, subject, snippet, body_path, has_attachments, attachments, date, is_read, is_starred, category, importance, ai_summary, suggested_action, action_reason, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.notes (id, user_id, workspace_id, title, content, snippet, content_type, domain, tags, audio_path, audio_duration, created_by_voice, ai_summary, confidence_score, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: task_session_links; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.task_session_links (task_id, instance_id, session_id, role, attached_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.tasks (id, title, description, status, priority, workstream_id, source, created_at, updated_at, pending_approvals, session_count) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.users (id, username, password_hash, role, created_at) FROM stdin;
\.


--
-- Data for Name: vault_sync; Type: TABLE DATA; Schema: public; Owner: llm_gateway
--

COPY public.vault_sync (user_id, blob_ciphertext, version, is_current, updated_at) FROM stdin;
\.


--
-- Name: asset_sync_log_id_seq; Type: SEQUENCE SET; Schema: opencode_pocket; Owner: llm_gateway
--

SELECT pg_catalog.setval('opencode_pocket.asset_sync_log_id_seq', 1, false);


--
-- Name: llm_gateway_configs_id_seq; Type: SEQUENCE SET; Schema: opencode_pocket; Owner: llm_gateway
--

SELECT pg_catalog.setval('opencode_pocket.llm_gateway_configs_id_seq', 1, true);


--
-- Name: llm_gateway_nodes_id_seq; Type: SEQUENCE SET; Schema: opencode_pocket; Owner: llm_gateway
--

SELECT pg_catalog.setval('opencode_pocket.llm_gateway_nodes_id_seq', 1, true);


--
-- Name: model_usage_id_seq; Type: SEQUENCE SET; Schema: opencode_pocket; Owner: llm_gateway
--

SELECT pg_catalog.setval('opencode_pocket.model_usage_id_seq', 1, false);


--
-- Name: quota_budgets_id_seq; Type: SEQUENCE SET; Schema: opencode_pocket; Owner: llm_gateway
--

SELECT pg_catalog.setval('opencode_pocket.quota_budgets_id_seq', 1, false);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: approval_observations approval_observations_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.approval_observations
    ADD CONSTRAINT approval_observations_pkey PRIMARY KEY (workspace_id, instance_id, session_id, request_id, kind);


--
-- Name: asset_mirrors asset_mirrors_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.asset_mirrors
    ADD CONSTRAINT asset_mirrors_pkey PRIMARY KEY (id);


--
-- Name: asset_sync_log asset_sync_log_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.asset_sync_log
    ADD CONSTRAINT asset_sync_log_pkey PRIMARY KEY (id);


--
-- Name: asset_workspace_revisions asset_workspace_revisions_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.asset_workspace_revisions
    ADD CONSTRAINT asset_workspace_revisions_pkey PRIMARY KEY (workspace_id);


--
-- Name: audit_entries audit_entries_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.audit_entries
    ADD CONSTRAINT audit_entries_pkey PRIMARY KEY (id);


--
-- Name: biometric_credentials biometric_credentials_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.biometric_credentials
    ADD CONSTRAINT biometric_credentials_pkey PRIMARY KEY (id);


--
-- Name: chat_agent_sync chat_agent_sync_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.chat_agent_sync
    ADD CONSTRAINT chat_agent_sync_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: chat_agents chat_agents_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.chat_agents
    ADD CONSTRAINT chat_agents_pkey PRIMARY KEY (id);


--
-- Name: daily_summaries daily_summaries_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.daily_summaries
    ADD CONSTRAINT daily_summaries_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: email_accounts email_accounts_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_accounts
    ADD CONSTRAINT email_accounts_pkey PRIMARY KEY (id);


--
-- Name: email_action_intents email_action_intents_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_action_intents
    ADD CONSTRAINT email_action_intents_pkey PRIMARY KEY (id);


--
-- Name: email_oauth_tokens email_oauth_tokens_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_oauth_tokens
    ADD CONSTRAINT email_oauth_tokens_pkey PRIMARY KEY (account_id);


--
-- Name: email_vacation_deliveries email_vacation_deliveries_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_vacation_deliveries
    ADD CONSTRAINT email_vacation_deliveries_pkey PRIMARY KEY (vacation_id, email_id);


--
-- Name: email_vacation_replies email_vacation_replies_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_vacation_replies
    ADD CONSTRAINT email_vacation_replies_pkey PRIMARY KEY (id);


--
-- Name: emails emails_account_id_message_id_key; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.emails
    ADD CONSTRAINT emails_account_id_message_id_key UNIQUE (account_id, message_id);


--
-- Name: emails emails_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.emails
    ADD CONSTRAINT emails_pkey PRIMARY KEY (id);


--
-- Name: llm_gateway_configs llm_gateway_configs_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.llm_gateway_configs
    ADD CONSTRAINT llm_gateway_configs_pkey PRIMARY KEY (id);


--
-- Name: llm_gateway_nodes llm_gateway_nodes_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.llm_gateway_nodes
    ADD CONSTRAINT llm_gateway_nodes_pkey PRIMARY KEY (id);


--
-- Name: model_usage model_usage_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.model_usage
    ADD CONSTRAINT model_usage_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notification_rules notification_rules_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.notification_rules
    ADD CONSTRAINT notification_rules_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: quota_budgets quota_budgets_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.quota_budgets
    ADD CONSTRAINT quota_budgets_pkey PRIMARY KEY (id);


--
-- Name: scheduled_task_runs scheduled_task_runs_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.scheduled_task_runs
    ADD CONSTRAINT scheduled_task_runs_pkey PRIMARY KEY (id);


--
-- Name: scheduled_tasks scheduled_tasks_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.scheduled_tasks
    ADD CONSTRAINT scheduled_tasks_pkey PRIMARY KEY (id);


--
-- Name: task_approval_projections task_approval_projections_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.task_approval_projections
    ADD CONSTRAINT task_approval_projections_pkey PRIMARY KEY (workspace_id, task_id, instance_id, session_id, request_id, kind);


--
-- Name: task_session_links task_session_links_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.task_session_links
    ADD CONSTRAINT task_session_links_pkey PRIMARY KEY (task_id, instance_id, session_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vault_sync vault_sync_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.vault_sync
    ADD CONSTRAINT vault_sync_pkey PRIMARY KEY (workspace_id, user_id, version);


--
-- Name: workspace_members workspace_members_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.workspace_members
    ADD CONSTRAINT workspace_members_pkey PRIMARY KEY (workspace_id, user_id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: daily_summaries daily_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.daily_summaries
    ADD CONSTRAINT daily_summaries_pkey PRIMARY KEY (id);


--
-- Name: daily_summaries daily_summaries_user_id_summary_date_key; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.daily_summaries
    ADD CONSTRAINT daily_summaries_user_id_summary_date_key UNIQUE (user_id, summary_date);


--
-- Name: email_accounts email_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_pkey PRIMARY KEY (id);


--
-- Name: emails emails_account_id_message_id_key; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.emails
    ADD CONSTRAINT emails_account_id_message_id_key UNIQUE (account_id, message_id);


--
-- Name: emails emails_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.emails
    ADD CONSTRAINT emails_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: task_session_links task_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.task_session_links
    ADD CONSTRAINT task_session_links_pkey PRIMARY KEY (task_id, instance_id, session_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vault_sync vault_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.vault_sync
    ADD CONSTRAINT vault_sync_pkey PRIMARY KEY (user_id, version);


--
-- Name: idx_action_intents_idem; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_action_intents_idem ON opencode_pocket.email_action_intents USING btree (idempotency_key);


--
-- Name: idx_action_intents_pending; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_action_intents_pending ON opencode_pocket.email_action_intents USING btree (status, created_at) WHERE (status = 'pending'::text);


--
-- Name: idx_agents_instance; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_agents_instance ON opencode_pocket.agents USING btree (instance_id);


--
-- Name: idx_agents_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_agents_ws ON opencode_pocket.agents USING btree (workspace_id);


--
-- Name: idx_approval_observations_session; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_approval_observations_session ON opencode_pocket.approval_observations USING btree (workspace_id, instance_id, session_id);


--
-- Name: idx_asset_mirrors_rev; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_asset_mirrors_rev ON opencode_pocket.asset_mirrors USING btree (workspace_id, server_rev, id);


--
-- Name: idx_asset_mirrors_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_asset_mirrors_ws ON opencode_pocket.asset_mirrors USING btree (workspace_id, updated_at DESC, id);


--
-- Name: idx_asset_sync_log_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_asset_sync_log_ws ON opencode_pocket.asset_sync_log USING btree (workspace_id, created_at DESC);


--
-- Name: idx_audit_entries_action_time; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_audit_entries_action_time ON opencode_pocket.audit_entries USING btree (action, "timestamp" DESC);


--
-- Name: idx_audit_entries_tenant_time; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_audit_entries_tenant_time ON opencode_pocket.audit_entries USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_audit_entries_user_time; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_audit_entries_user_time ON opencode_pocket.audit_entries USING btree (user_id, "timestamp" DESC);


--
-- Name: idx_biometric_user; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_biometric_user ON opencode_pocket.biometric_credentials USING btree (user_id, workspace_id);


--
-- Name: idx_chat_agents_builtin; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_chat_agents_builtin ON opencode_pocket.chat_agents USING btree (is_builtin);


--
-- Name: idx_chat_agents_dept; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_chat_agents_dept ON opencode_pocket.chat_agents USING btree (department);


--
-- Name: idx_chat_agents_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_chat_agents_ws ON opencode_pocket.chat_agents USING btree (workspace_id);


--
-- Name: idx_daily_summaries_user; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_daily_summaries_user ON opencode_pocket.daily_summaries USING btree (user_id);


--
-- Name: idx_daily_summaries_user_ws_date; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_daily_summaries_user_ws_date ON opencode_pocket.daily_summaries USING btree (user_id, workspace_id, summary_date);


--
-- Name: idx_devices_user; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_devices_user ON opencode_pocket.devices USING btree (user_id);


--
-- Name: idx_devices_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_devices_ws ON opencode_pocket.devices USING btree (workspace_id);


--
-- Name: idx_email_accounts_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_email_accounts_ws ON opencode_pocket.email_accounts USING btree (workspace_id);


--
-- Name: idx_email_oauth_tokens_expires; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_email_oauth_tokens_expires ON opencode_pocket.email_oauth_tokens USING btree (expires_at);


--
-- Name: idx_email_oauth_tokens_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_email_oauth_tokens_ws ON opencode_pocket.email_oauth_tokens USING btree (workspace_id);


--
-- Name: idx_emails_category; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_emails_category ON opencode_pocket.emails USING btree (category);


--
-- Name: idx_emails_date; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_emails_date ON opencode_pocket.emails USING btree (date DESC);


--
-- Name: idx_emails_importance; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_emails_importance ON opencode_pocket.emails USING btree (importance);


--
-- Name: idx_emails_subject_date; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_emails_subject_date ON opencode_pocket.emails USING btree (account_id, subject, date) WHERE (message_id IS NULL);


--
-- Name: idx_emails_unread; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_emails_unread ON opencode_pocket.emails USING btree (is_read) WHERE (is_read = false);


--
-- Name: idx_emails_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_emails_ws ON opencode_pocket.emails USING btree (workspace_id);


--
-- Name: idx_llm_gw_active_per_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_llm_gw_active_per_ws ON opencode_pocket.llm_gateway_configs USING btree (workspace_id) WHERE is_active;


--
-- Name: idx_llm_gw_nodes_ws_name; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_llm_gw_nodes_ws_name ON opencode_pocket.llm_gateway_nodes USING btree (workspace_id, name);


--
-- Name: idx_llm_gw_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_llm_gw_ws ON opencode_pocket.llm_gateway_configs USING btree (workspace_id);


--
-- Name: idx_model_usage_kind; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_model_usage_kind ON opencode_pocket.model_usage USING btree (kind);


--
-- Name: idx_model_usage_model; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_model_usage_model ON opencode_pocket.model_usage USING btree (model);


--
-- Name: idx_model_usage_ws_time; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_model_usage_ws_time ON opencode_pocket.model_usage USING btree (workspace_id, created_at DESC);


--
-- Name: idx_notes_updated; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_notes_updated ON opencode_pocket.notes USING btree (updated_at DESC);


--
-- Name: idx_notes_user_domain; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_notes_user_domain ON opencode_pocket.notes USING btree (user_id, domain);


--
-- Name: idx_notif_rules_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_notif_rules_ws ON opencode_pocket.notification_rules USING btree (workspace_id, enabled);


--
-- Name: idx_notif_unread; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_notif_unread ON opencode_pocket.notifications USING btree (workspace_id, read_at) WHERE (read_at = 0);


--
-- Name: idx_notif_ws_time; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_notif_ws_time ON opencode_pocket.notifications USING btree (workspace_id, created_at DESC);


--
-- Name: idx_quota_budgets_window; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_quota_budgets_window ON opencode_pocket.quota_budgets USING btree (workspace_id, period_start, period_end);


--
-- Name: idx_quota_budgets_ws_kind; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_quota_budgets_ws_kind ON opencode_pocket.quota_budgets USING btree (workspace_id, kind);


--
-- Name: idx_runs_owner; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_runs_owner ON opencode_pocket.scheduled_task_runs USING btree (user_id, workspace_id, started_at DESC);


--
-- Name: idx_runs_task; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_runs_task ON opencode_pocket.scheduled_task_runs USING btree (task_id, started_at DESC);


--
-- Name: idx_scheduled_tasks_due; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_scheduled_tasks_due ON opencode_pocket.scheduled_tasks USING btree (next_run_at) WHERE (enabled = true);


--
-- Name: idx_scheduled_tasks_owner; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_scheduled_tasks_owner ON opencode_pocket.scheduled_tasks USING btree (user_id, workspace_id);


--
-- Name: idx_task_approval_projections_pending; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_task_approval_projections_pending ON opencode_pocket.task_approval_projections USING btree (workspace_id, task_id, state);


--
-- Name: idx_task_approval_projections_session; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_task_approval_projections_session ON opencode_pocket.task_approval_projections USING btree (workspace_id, instance_id, session_id);


--
-- Name: idx_tasks_accepted_status; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_tasks_accepted_status ON opencode_pocket.tasks USING btree (workspace_id, status) WHERE (status = 'accepted'::text);


--
-- Name: idx_tasks_workspace; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_tasks_workspace ON opencode_pocket.tasks USING btree (workspace_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_users_username ON opencode_pocket.users USING btree (username);


--
-- Name: idx_vacation_deliveries_recipient; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_vacation_deliveries_recipient ON opencode_pocket.email_vacation_deliveries USING btree (vacation_id, recipient, claimed_at DESC);


--
-- Name: idx_vacation_deliveries_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_vacation_deliveries_ws ON opencode_pocket.email_vacation_deliveries USING btree (workspace_id, status);


--
-- Name: idx_vacation_replies_ws; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_vacation_replies_ws ON opencode_pocket.email_vacation_replies USING btree (workspace_id, enabled);


--
-- Name: idx_vault_sync_one_current; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_vault_sync_one_current ON opencode_pocket.vault_sync USING btree (workspace_id, user_id) WHERE is_current;


--
-- Name: idx_vault_user; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_vault_user ON opencode_pocket.vault_sync USING btree (workspace_id, user_id);


--
-- Name: idx_wm_user; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_wm_user ON opencode_pocket.workspace_members USING btree (user_id);


--
-- Name: idx_workspaces_owner; Type: INDEX; Schema: opencode_pocket; Owner: llm_gateway
--

CREATE INDEX idx_workspaces_owner ON opencode_pocket.workspaces USING btree (owner_id);


--
-- Name: idx_daily_summaries_user; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_daily_summaries_user ON public.daily_summaries USING btree (user_id);


--
-- Name: idx_emails_category; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_emails_category ON public.emails USING btree (category);


--
-- Name: idx_emails_date; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_emails_date ON public.emails USING btree (date DESC);


--
-- Name: idx_emails_importance; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_emails_importance ON public.emails USING btree (importance);


--
-- Name: idx_emails_subject_date; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE UNIQUE INDEX idx_emails_subject_date ON public.emails USING btree (account_id, subject, date) WHERE (message_id IS NULL);


--
-- Name: idx_emails_unread; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_emails_unread ON public.emails USING btree (is_read) WHERE (is_read = false);


--
-- Name: idx_notes_updated; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_notes_updated ON public.notes USING btree (updated_at DESC);


--
-- Name: idx_notes_user_domain; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_notes_user_domain ON public.notes USING btree (user_id, domain);


--
-- Name: idx_vault_user; Type: INDEX; Schema: public; Owner: llm_gateway
--

CREATE INDEX idx_vault_user ON public.vault_sync USING btree (user_id);


--
-- Name: email_action_intents email_action_intents_account_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_action_intents
    ADD CONSTRAINT email_action_intents_account_id_fkey FOREIGN KEY (account_id) REFERENCES opencode_pocket.email_accounts(id) ON DELETE CASCADE;


--
-- Name: email_action_intents email_action_intents_email_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_action_intents
    ADD CONSTRAINT email_action_intents_email_id_fkey FOREIGN KEY (email_id) REFERENCES opencode_pocket.emails(id) ON DELETE CASCADE;


--
-- Name: email_oauth_tokens email_oauth_tokens_account_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_oauth_tokens
    ADD CONSTRAINT email_oauth_tokens_account_id_fkey FOREIGN KEY (account_id) REFERENCES opencode_pocket.email_accounts(id) ON DELETE CASCADE;


--
-- Name: email_vacation_deliveries email_vacation_deliveries_email_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_vacation_deliveries
    ADD CONSTRAINT email_vacation_deliveries_email_id_fkey FOREIGN KEY (email_id) REFERENCES opencode_pocket.emails(id) ON DELETE CASCADE;


--
-- Name: email_vacation_deliveries email_vacation_deliveries_vacation_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_vacation_deliveries
    ADD CONSTRAINT email_vacation_deliveries_vacation_id_fkey FOREIGN KEY (vacation_id) REFERENCES opencode_pocket.email_vacation_replies(id) ON DELETE CASCADE;


--
-- Name: email_vacation_replies email_vacation_replies_account_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.email_vacation_replies
    ADD CONSTRAINT email_vacation_replies_account_id_fkey FOREIGN KEY (account_id) REFERENCES opencode_pocket.email_accounts(id) ON DELETE CASCADE;


--
-- Name: emails emails_account_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.emails
    ADD CONSTRAINT emails_account_id_fkey FOREIGN KEY (account_id) REFERENCES opencode_pocket.email_accounts(id) ON DELETE CASCADE;


--
-- Name: scheduled_task_runs scheduled_task_runs_task_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.scheduled_task_runs
    ADD CONSTRAINT scheduled_task_runs_task_id_fkey FOREIGN KEY (task_id) REFERENCES opencode_pocket.scheduled_tasks(id) ON DELETE CASCADE;


--
-- Name: task_approval_projections task_approval_projections_task_id_fkey; Type: FK CONSTRAINT; Schema: opencode_pocket; Owner: llm_gateway
--

ALTER TABLE ONLY opencode_pocket.task_approval_projections
    ADD CONSTRAINT task_approval_projections_task_id_fkey FOREIGN KEY (task_id) REFERENCES opencode_pocket.tasks(id) ON DELETE CASCADE;


--
-- Name: emails emails_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: llm_gateway
--

ALTER TABLE ONLY public.emails
    ADD CONSTRAINT emails_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.email_accounts(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4LKccdtQgsu6X0lZc4h5dtPNwPid50xrZ9cidFtqfSwsQDgtgPKbi1bE8h4b80F

